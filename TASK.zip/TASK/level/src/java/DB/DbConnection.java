
package DB;
import java.sql.*;
public class DbConnection {
 public Connection con;
    public Statement stmt;
    public PreparedStatement pstmt;
    public ResultSet rst;

    public DbConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");

        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/levels", "root", "qwerty");
        stmt = con.createStatement();
        pstmt = null;
        rst = null;
    }
      
}
