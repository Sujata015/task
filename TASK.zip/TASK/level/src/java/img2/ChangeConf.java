
package img2;

import DB.DBCon;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ChangeConf", urlPatterns = {"/ChangeConf"})
public class ChangeConf extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
         out.println("ok1");   
            String oldpass=request.getParameter("t1");
            String newpass=request.getParameter("t2");
            String conpass=request.getParameter("t3");
         out.println("ok2");   
            
            if(newpass.equals(conpass))
            {
                
         
                 HttpSession session = request.getSession();
                 String user=(String) session.getAttribute("email");
                 String pswd=(String) session.getAttribute("pass");
               
         
                 if(oldpass.equals(pswd))
               {
                  
         
                   DBCon db=new DBCon();
                   db.pstmt=db.con.prepareStatement("update registration set Password=? where Email=?");
                   db.pstmt.setString(1, newpass);
                   db.pstmt.setString(2, user);
                   out.println("ok6");   
         
                   int i=db.pstmt.executeUpdate();
                   
         
                   if(i>0)
                   {
                       out.println("Password Updated Successfully");
                       response.sendRedirect("index.jsp");
                   }
                   
               }
               else
               {
                out.println("Old Password does not Match");
             }
            
            }
             else
             {
                 out.println("new and Confirm Password does not Match");
             }
            
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
